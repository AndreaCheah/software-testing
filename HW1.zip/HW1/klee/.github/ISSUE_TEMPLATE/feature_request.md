---
name: Feature request
about: Suggest a feature in KLEE
title: ''
labels: ''
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is.  E.g., I find it difficult to use KLEE when [...]; I would find it very useful for KLEE to [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.
