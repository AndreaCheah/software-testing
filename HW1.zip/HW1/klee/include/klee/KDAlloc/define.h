//===-- define.h ------------------------------------------------*- C++ -*-===//
//
//                     The KLEE Symbolic Virtual Machine
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef KDALLOC_DEFINE_H
#define KDALLOC_DEFINE_H

#ifndef KDALLOC_TRACE
#define KDALLOC_TRACE 0
#endif

#endif
