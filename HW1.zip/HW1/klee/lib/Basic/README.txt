This directory holds the most basic support facilities provided for
both the klee and kleaver libraries. The code in this directory should
have no dependencies on LLVM or any other klee libraries.
