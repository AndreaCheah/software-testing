void* __dso_handle = 0;
